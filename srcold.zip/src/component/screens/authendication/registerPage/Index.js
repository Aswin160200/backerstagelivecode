import React from "react";
import Styles from "./Index.module.css"

const RegisterPage=()=>{
    return(
        <div></div>
    )
}
export default RegisterPage