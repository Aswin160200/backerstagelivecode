import React from "react";
import Styles from "./Index.module.css"
import HeaderPage from "../../pages/header/Header";

const LandingPage=()=>{
    return(
        <div >
        </div>
    )
}
export default LandingPage